$(document).ready(function() {
  $("#circle").draggable();
});